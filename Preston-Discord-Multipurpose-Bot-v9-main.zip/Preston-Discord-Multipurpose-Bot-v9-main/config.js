const data = {
    "token": "" || process.env.token,
    "mongo": ""|| process.env.mongo,
 
}
console.log('got connected from database ..!!')
module.exports = data;